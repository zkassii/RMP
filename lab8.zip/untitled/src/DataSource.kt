package datasource

interface DataSource<T> {
    fun getNext(): T?
}
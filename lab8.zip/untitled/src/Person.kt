package person

open class Person(val name: String, val age: Int) {
    open val fullInfo: String
        get() = "Человек: $name, возраст: $age лет"

    open fun printInfo() {
        println("Имя: $name")
        println("Возраст: $age")
    }

    override fun toString(): String {
        return "Person: $name, $age лет"
    }
}
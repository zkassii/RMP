package person

class Student(name: String, age: Int, val group: String) : Person(name, age) {

    override val fullInfo: String
        get() = "Студент: $name, $age лет, группа: $group"

    override fun printInfo() {
        super.printInfo()
        println("Группа: $group")
    }

    override fun toString(): String {
        return "${super.toString()} (Студент группы $group)"
    }
}
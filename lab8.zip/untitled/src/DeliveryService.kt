package delivery

interface DeliveryService {
    val serviceName: String
    fun deliver(orderNumber: String)
}
package datasource

class StaticDataSource<T>(private val data: Array<T>) : DataSource<T> {
    private var index = 0

    override fun getNext(): T? {
        return if (index < data.size) data[index++]
        else null
    }
}
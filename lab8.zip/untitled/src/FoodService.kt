package delivery

class FoodService : DeliveryService {
    override val serviceName: String = "dostavkaedi"

    override fun deliver(orderNumber: String) {
        println("Заказ $orderNumber передан в доставку через $serviceName")
    }
}
package datasource

class RandomDataSource : DataSource<Int> {
    private var count = 0

    override fun getNext(): Int? {
        return if (count < 20) {
            count++
            (1..100).random()
        } else null
    }
}
package figure

class Rectangle(
    private val width: Double,
    private val height: Double
) : Figure() {

    override val name: String = "Прямоугольник"

    override fun area(): Double = width * height
    override fun perimeter(): Double = 2 * (width + height)

    override fun printInfo() {
        println("Фигура: $name")
        println("Ширина: $width")
        println("Высота: $height")
        println("Площадь: ${area()}")
        println("Периметр: ${perimeter()}")
    }
}
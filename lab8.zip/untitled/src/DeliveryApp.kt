package delivery

class DeliveryApp(private val deliveryService: DeliveryService) : DeliveryService by deliveryService {

    fun createOrder(orderNumber: String) {
        println("Создаём заказ №$orderNumber")
        deliver(orderNumber)
    }
}
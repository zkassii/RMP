import datasource.DataSource
import datasource.RandomDataSource
import datasource.StaticDataSource
import delivery.DeliveryApp
import delivery.FoodService
import figure.Rectangle
import person.Person
import person.Student

fun main() {
    // 5.1 5.2
    testPersonAndStudent()
    // 5.3
    testFigure()
    // 5.4
    testDataSource()
    // 5.5
    testDelivery()
}

fun testPersonAndStudent() {
    val person = Person("Иван Иванов", 50)
    val student = Student("Петр Петров", 20, "ИСПП")

    println(person)
    println(student)
    println(person.fullInfo)
    println(student.fullInfo)
    person.printInfo()
    student.printInfo()
    println()
}

fun testFigure() {
    val rect = Rectangle(10.5, 7.0)
    rect.printInfo()
    println()
}

fun testDataSource() {
    val randomSource = RandomDataSource()
    val staticSource = StaticDataSource(arrayOf("Яблоко", "Апельсин", "Личи", "Банан", "Манго"))

    print10Elements(randomSource)
    print10Elements(staticSource)
}

fun testDelivery() {
    val foodService = FoodService()
    val app = DeliveryApp(foodService)
    app.createOrder("123")
    println()
}

// Функция из 5.4.4
fun print10Elements(source: DataSource<*>) {
    println("Выводим до 10 элементов:")
    for (i in 1..10) {
        val item = source.getNext()
        if (item != null) {
            println("  $i: $item")
        } else {
            println("  Элементы закончились")
            break
        }
    }
    println()
}
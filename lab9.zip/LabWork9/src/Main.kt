fun main() {

    // 5.1 Список животных
    val animals = mutableListOf("Кот", "Собака", "Шиншилла")

    // Добавляем 3 элемента программно
    animals.add("Морская свинка")
    animals.add("Медведь")
    animals.add("Волк")

    // Добавляем n элементов с клавиатуры
    print("Введите количество животных для добавления: ")
    val n1 = readln().toInt()
    for (i in 1..n1) {
        print("Введите животное $i: ")
        animals.add(readln())
    }

    println("\nСписок животных:")
    for (i in animals.indices) {
        println("${i + 1} – ${animals[i]}")
    }
    println("Количество элементов: ${animals.size}")


    // 5.2 Список целых чисел
    val numbers = mutableListOf<Int>()

    print("\nВведите количество чисел: ")
    val n2 = readln().toInt()
    for (i in 1..n2) {
        print("Введите число $i: ")
        numbers.add(readln().toInt())
    }

    // Индекс 100
    val index100 = numbers.indexOf(100)
    if (index100 != -1) {
        println("Индекс элемента 100: $index100")
    } else {
        println("Элемента 100 нет в списке")
    }

    println("Сумма элементов: ${numbers.sum()}")
    if (numbers.isNotEmpty()) {
        println("Среднее значение: %.2f".format(numbers.average()))
    }
    println("Все числа больше нуля: ${numbers.all { it > 0 }}")
    val oddNumbers = numbers.filter { it % 2 != 0 }
    println("Нечетные значения: $oddNumbers")


    // 5.3 Словарь: Название фильма — Режиссёр
    val movies = mutableMapOf(
        "Интерстеллар" to "Кристофер Нолан",
        "Мастер и Маргарита " to "Михаил Локшин",
        "Горничная" to "Пол Фиг"
    )

    // Добавляем 3 элемента программно
    movies["Дюна"] = "Дени Вильнев"
    movies["Оппенгеймер"] = "Кристофер Нолан"
    movies["Дьявол носит Prada 2"] = "Дэвид Фрэнкел"

    // Добавляем n элементов с клавиатуры
    print("\nВведите количество фильмов для добавления: ")
    val n3 = readln().toInt()
    for (i in 1..n3) {
        print("Введите название фильма: ")
        val title = readln()
        print("Введите режиссера: ")
        val director = readln()
        movies[title] = director
    }

    println("\nСловарь фильмов:")
    for ((title, director) in movies) {
        println("$title – $director")
    }
    println("Количество элементов: ${movies.size}")


    // 5.4 Работа со словарем
    print("\nВведите название фильма для поиска: ")
    val searchKey = readln()
    if (searchKey in movies) {
        println("Найдено: ${movies[searchKey]}")
    } else {
        println("Такого фильма нет")
    }

    print("Введите режиссера для подсчёта: ")
    val searchDirector = readln()
    val count = movies.count { it.value == searchDirector }
    println("Количество фильмов этого режиссера: $count")

    print("Введите название фильма для удаления: ")
    val delKey = readln()
    if (movies.remove(delKey) != null) {
        println("Фильм удалён")
    } else {
        println("Фильм не найден")
    }

    println("\nОбновлённый словарь:")
    for ((title, director) in movies) {
        println("$title – $director")
    }

    // 5.5 Множества студентов
    val group1 = mutableSetOf("Иванов И.И.", "Петров П.П.", "Малявкин М.М.", "Орлов О.О.")
    val group2 = mutableSetOf("Петров П.П.", "Малявкин М.М.", "Смирнова С.С.", "Машкин М.М.")

    val allRetake = group1 union group2
    val bothFailed = group1 intersect group2
    val onlyOne = (group1 union group2) - (group1 intersect group2)

    println("\nВсего на пересдачу: ${allRetake.size} студентов")
    println("Список: $allRetake")

    println("Не сдали оба зачета: ${bothFailed.size} студентов")
    println("Список: $bothFailed")

    println("Сдали только один зачет: ${onlyOne.size} студентов")
    println("Список: $onlyOne")
}
package com.example.labwork16

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LabWork16Theme {
                MainScreen()
            }
        }
    }
}

@Composable
fun LabWork16Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = colorResource(id = R.color.primary_color),
            background = colorResource(id = R.color.background_color)
        )
    ) {
        content()
    }
}

@Composable
fun MainScreen() {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val developers = stringArrayResource(id = R.array.developers)
    val devName = developers.firstOrNull() ?: "Developer"

    val c = Calendar.getInstance()
    val hour = c.get(Calendar.HOUR_OF_DAY)
    val minute = c.get(Calendar.MINUTE)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colorResource(id = R.color.background_color))
            .verticalScroll(scrollState)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(id = R.string.app_name),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colorResource(id = R.color.text_color)
            )

            OutlinedTextField(
                value = "",
                onValueChange = {},
                placeholder = { Text(stringResource(R.string.search)) },
                modifier = Modifier
                    .weight(1f)
                    .height(dimensionResource(id = R.dimen.search_height))
                    .padding(horizontal = 8.dp)
            )

            IconButton(
                onClick = {},
                modifier = Modifier.size(dimensionResource(id = R.dimen.menu_button_size))
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_menu),
                    contentDescription = stringResource(R.string.menu),
                    tint = colorResource(id = R.color.accent_color)
                )
            }
        }

        // Content
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Copyright
            Text(
                text = stringResource(
                    id = R.string.copyright,
                    devName,
                    2026
                ),
                fontSize = 14.sp
            )

            // Time with plurals
            Text(
                text = "${pluralStringResource(R.plurals.hours, hour, hour)} " +
                        "${pluralStringResource(R.plurals.minutes, minute, minute)}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium
            )

            // Developers list
            Text("Разработчики:", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            developers.forEach { dev ->
                Text("• $dev")
            }

            // Vector Image
            Text("Векторное изображение:", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Image(
                painter = painterResource(id = R.drawable.ic_vector),
                contentDescription = "Vector Icon",
                modifier = Modifier.size(80.dp),
                colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(Color.Blue)
            )

            // Raster Image (circular)
            Text("Растровое изображение (круглое):", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Image(
                painter = painterResource(id = R.drawable.sample_image),
                contentDescription = "Raster Image",
                modifier = Modifier
                    .size(dimensionResource(id = R.dimen.image_size))
                    .clip(CircleShape)
            )

            // Custom Font Example
            Text(
                text = "Текст с кастомным шрифтом",
                fontFamily = CustomFonts.customFont,
                fontSize = 18.sp
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

object CustomFonts {
    val customFont: FontFamily = FontFamily(
        Font(resId = R.font.custom_font)
    )
}
